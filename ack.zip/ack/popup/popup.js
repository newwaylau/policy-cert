var popupMsg = document.getElementById('ack-popup-wrapper')

var cancleSpan = document.querySelector('.cancle')

var ackFlag = true
  if (ackFlag) {
  popupMsg.style.display = 'flex'
  document.body.style.overflow = 'disable'
  }
cancleSpan.onclick = function () {
  popupMsg.style.display = 'none'
  ackFlag = false;
}
window.onclick = function (event) {
  if (event.target == popupMsg) {
    popupMsg.style.display = 'none'
  } 
}